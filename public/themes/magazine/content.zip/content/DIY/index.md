---
template: subindex
title: DIY
description: Do-it-yourself projects
thumbnail: https://hourofpower.de/wp-content/uploads/2018/04/HOP_www_DIY_800x534.jpg
---